export const headerMenu = [
  {
    label: "Home",
    path: "#home"
  },
  {
    label: "About",
    path: "#about"
  },
  {
    label: "Mint",
    path: "#mint"
  },
  {
    label: "Rarity",
    path: "#rarity"
  },
  {
    label: "Roadmap",
    path: "#roadmap"
  },
  {
    label: "FAQ",
    path: "#faq"
  },
  {
    label: "Team",
    path: "#team"
  },
]